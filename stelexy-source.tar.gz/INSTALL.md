Building Stelexy
================

See doc/build-*.md for instructions on building the various
elements of the Stelexy Core reference implementation of Stelexy.
