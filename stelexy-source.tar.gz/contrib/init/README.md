Sample configuration files for:
```
SystemD: stelexyd.service
Upstart: stelexyd.conf
OpenRC:  stelexyd.openrc
         stelexyd.openrcconf
CentOS:  stelexyd.init
macOS:   org.stelexy.stelexyd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
